<?php
	session_start();
	if(!isset($_POST['submit'])){
	
	require_once "./functions/database_functions.php";
	$conn = db_connect();

	$name = trim($_POST['name']);
	$pass = trim($_POST['pass']);
	$_SESSION['err_login'] = "Username Dan Pasword Anda Salah";

	$name = mysqli_real_escape_string($conn, $name);
	$pass = mysqli_real_escape_string($conn, $pass);
	$pass = sha1($pass);
	$_SESSION['err_login'] = "Isi Username Dan Password Anda";

	// get from db
	$query = "SELECT * from `admin` where `name` = '{$name}' and `pass` ='{$pass}'";
	$result = mysqli_query($conn, $query);
	if($result->num_rows <= 0){
		$_SESSION['err_login'] = "Incorrect Username or Password";
		header("Location: admin.php");
		exit;
	}
}
	if(isset($conn)) {mysqli_close($conn);}
	$_SESSION['admin'] = true;
	header("Location: admin_book.php");
?>